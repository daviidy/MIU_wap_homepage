/**
 * dbconfig.js
 */
'use strict'

const dbConfig = {
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'bank_app_express'
}
module.exports = dbConfig
